# Bingus Clicker

THIS GAME HAS MADE ME RETHINK MY LIFE!

## Who's behind this?

* Descendo The Monkei#0624 - Wasted His Life Making This.
